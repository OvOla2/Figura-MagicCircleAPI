-- Auto generated script file --
local MagicCircleAPI = require("MagicCircleAPI")
MagicCircleAPI.init()
